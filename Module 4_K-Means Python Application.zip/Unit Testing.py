
import unittest
import numpy as np

from kmeans_cyber import KMeans  # Import from your main file (adjust if named differently)

class TestKMeans(unittest.TestCase):
    def setUp(self):
        # Synthetic data: two clear clusters
        self.X = np.array([
            [1, 2], [1, 4], [1, 0],  # Cluster 1
            [10, 2], [10, 4], [10, 0]  # Cluster 2
        ])
        self.kmeans = KMeans(n_clusters=2)

    def test_fit_convergence(self):
        self.kmeans.fit(self.X)
        # Check if centroids are close to expected means
        expected_centroids = np.array([[1, 2], [10, 2]])
        sorted_centroids = np.sort(self.kmeans.centroids, axis=0)
        sorted_expected = np.sort(expected_centroids, axis=0)
        np.testing.assert_allclose(sorted_centroids, sorted_expected, atol=0.5)

    def test_predict(self):
        self.kmeans.fit(self.X)
        # Predict on new points
        new_points = np.array([[0, 0], [11, 3]])
        predictions = self.kmeans.predict(new_points)
        self.assertEqual(predictions[0], self.kmeans.predict(np.array([[1, 2]]))[0])  # Should be in cluster 1
        self.assertEqual(predictions[1], self.kmeans.predict(np.array([[10, 2]]))[0])  # Should be in cluster 2

    def test_empty_cluster_handling(self):
        # Test with data that might cause empty clusters (rare init)
        X_small = np.array([[1, 1], [2, 2], [3, 3]])
        kmeans = KMeans(n_clusters=3)  # More clusters than points, but handles reinitialization
        kmeans.fit(X_small)
        self.assertIsNotNone(kmeans.centroids)  # Ensures no crash

if __name__ == '__main__':
    unittest.main()