# from https://registry.opendata.aws/ , "A Realistic Cyber Defence Dataset (CSE-CIC-IDS2018)" was selected
# Developing K-Mean using the  dataset

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


class KMeans:
    """
    K-Means clustering algorithm implementation from scratch.
    """

    def __init__(self, n_clusters: int, max_iter: int = 300, tol: float = 1e-4):
        """
        Initialize the KMeans model.
        :param n_clusters: Number of clusters (k).
        :param max_iter: Maximum number of iterations.
        :param tol: Tolerance for convergence.
        """
        self.n_clusters = n_clusters
        self.max_iter = max_iter
        self.tol = tol
        self.centroids = None
        self.labels_ = None

    def fit(self, X: np.ndarray) -> None:
        """
        Fit the model to the data.
        :param X: Input data (n_samples, n_features).
        """
        n_samples, n_features = X.shape
        # Initialize centroids randomly from data points
        rng = np.random.default_rng()
        self.centroids = X[rng.choice(n_samples, self.n_clusters, replace=False)]

        for _ in range(self.max_iter):
            # Compute distances to centroids and assign labels
            distances = np.linalg.norm(X[:, np.newaxis] - self.centroids, axis=2)
            labels = np.argmin(distances, axis=1)

            # Compute new centroids as mean of points in each cluster
            new_centroids = np.zeros((self.n_clusters, n_features))
            for k in range(self.n_clusters):
                cluster_points = X[labels == k]
                if len(cluster_points) > 0:
                    new_centroids[k] = cluster_points.mean(axis=0)
                else:
                    # If empty cluster, reinitialize randomly
                    new_centroids[k] = X[rng.choice(n_samples)]

            # Check for convergence
            shift = np.linalg.norm(new_centroids - self.centroids)
            self.centroids = new_centroids
            if shift <= self.tol:
                break

        self.labels_ = labels

    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Predict cluster labels for new data.
        :param X: Input data.
        :return: Cluster labels.
        """
        distances = np.linalg.norm(X[:, np.newaxis] - self.centroids, axis=2)
        return np.argmin(distances, axis=1)


# Main application
if __name__ == "__main__":
    # Load dataset from AWS S3 (public URL)
    url = "https://cse-cic-ids2018.s3.ca-central-1.amazonaws.com/Wednesday-14-02-2018_TrafficForML_CICFlowMeter.csv"
    print("Loading dataset...")
    df = pd.read_csv(url)

    # Preprocess: Select numerical columns, drop NaNs, normalize
    numerical_cols = df.select_dtypes(include=['float64', 'int64']).columns
    df_num = df[numerical_cols].dropna()

    # Sample 2000 rows for efficiency (full dataset is large)
    df_sample = df_num.sample(n=2000, random_state=42)
    X = df_sample.values

    # Normalize features (mean=0, std=1)
    X = (X - X.mean(axis=0)) / X.std(axis=0)

    # Run K-Means (e.g., 2 clusters for benign vs. attack patterns)
    print("Running K-Means...")
    kmeans = KMeans(n_clusters=2)
    kmeans.fit(X)

    # Visualize using first two features (for simplicity; in practice, use PCA if needed)
    plt.scatter(X[:, 0], X[:, 1], c=kmeans.labels_, cmap='viridis')
    plt.scatter(kmeans.centroids[:, 0], kmeans.centroids[:, 1], c='red', marker='x', s=100)
    plt.title('K-Means Clustering on Cyber Dataset (First Two Features)')
    plt.xlabel('Feature 1 (Normalized)')
    plt.ylabel('Feature 2 (Normalized)')
    plt.show()

    print("Clustering complete. Labels:", kmeans.labels_[:10])